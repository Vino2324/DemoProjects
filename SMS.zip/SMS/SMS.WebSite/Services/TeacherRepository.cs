﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{

    public class TeacherRepository : ITeacherRepository
    {
        public TeacherRepository()
        {
        }

        public IEnumerable<Teacher> GetAll()
        {
           // return db.Books;
            return null;
        }

        public Teacher Get(int id)
        {
           // return db.Books.Find(id);
            return null;
        }

        public Teacher Add(Teacher item)
        {
            //db.Books.Add(item);
            //db.SaveChanges();
            //return item;

            return null;
        }

        public void Remove(int id)
        {
            //Student book = db.Books.Find(id);
            //db.Books.Remove(book);
            //db.SaveChanges();

            
        }

        public bool Update(Teacher item)
        {
            //db.Entry(item).State = EntityState.Modified;
            //db.SaveChanges();
            return true;

        }
    }
}
