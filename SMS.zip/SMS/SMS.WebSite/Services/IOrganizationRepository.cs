﻿using System.Collections.Generic;

namespace SMS
{
    public interface IOrganizationRepository
    {
        IEnumerable<Organization> GetAll();
        Organization Get(int id);
        Organization Add(Organization item);
        void Remove(int id);
        bool Update(Organization item);
    }
}
