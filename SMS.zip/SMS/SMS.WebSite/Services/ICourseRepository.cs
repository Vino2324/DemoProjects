﻿using System.Collections.Generic;

namespace SMS
{
    public interface ICourseRepository
    {
        IEnumerable<Course> GetAll();
        Course Get(int id);
        Course Add(Course item);
        void Remove(int id);
        bool Update(Course item);
    }
}
