﻿using System.Collections.Generic;

namespace SMS
{
    public interface IFeeInformationRepository
    {
        IEnumerable<FeeInformation> GetAll();
        FeeInformation Get(int id);
        FeeInformation Add(FeeInformation item);
        void Remove(int id);
        bool Update(FeeInformation item);
    }
}
