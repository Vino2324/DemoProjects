﻿using System.Collections.Generic;

namespace SMS
{
    public interface IFamilyRepository
    {
        IEnumerable<Family> GetAll();
        Family Get(int id);
        Family Add(Family item);
        void Remove(int id);
        bool Update(Family item);
    }
}
