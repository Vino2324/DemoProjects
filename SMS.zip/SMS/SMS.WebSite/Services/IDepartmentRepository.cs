﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SMS
{ 
    public interface IDepartmentRepository
    {
        IEnumerable<Department> GetAll();
        Department Get(int id);
        Department Add(Department item);
        void Remove(int id);
        bool Update(Department item);
    }
}
