﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{   

    public class AttendanceRepository : IAttendanceRepository
    {
        public AttendanceRepository()
        {

        }

        public IEnumerable<Attendance> GetAll()
        {
           // return db.Books;
            return null;
        }

        public Attendance Get(int id)
        {
           // return db.Books.Find(id);
            return null;
        }

        public Attendance Add(Attendance item)
        {
            //db.Books.Add(item);
            //db.SaveChanges();
            //return item;

            return null;
        }

        public void Remove(int id)
        {
            //Student book = db.Books.Find(id);
            //db.Books.Remove(book);
            //db.SaveChanges();           
        }

        public bool Update(Attendance item)
        {
            //db.Entry(item).State = EntityState.Modified;
            //db.SaveChanges();
            return true;

        }
    }
}
