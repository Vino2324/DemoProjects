﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{

    public class StudentRepository : IStudentRepository
    {

        List<Student> students = null;


        public StudentRepository()
        {

       students = new List<Student>()
        
        {
      new Student { OrgId = 1, StudentId=1,  FirstName = "Ganesan", LastName = "R", FamilyId = 1, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=2,  FirstName = "Vinoth", LastName = "V", FamilyId = 2, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=3,  FirstName = "Vetri", LastName = "V", FamilyId = 2, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=4,  FirstName = "Chandra", LastName = "S", FamilyId = 3, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=5,  FirstName = "Hariharan", LastName = "P", FamilyId = 4, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=6,  FirstName = "Harish", LastName = "K", FamilyId = 5, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=7,  FirstName = "Anish", LastName = "L", FamilyId = 6, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=8,  FirstName = "Tanush", LastName = "L", FamilyId = 6, Gender="M",DOB=DateTime.Now,CourseId=1 }, 
      new Student { OrgId = 1, StudentId=9,  FirstName = "Pranav", LastName = "P", FamilyId = 7, Gender="M",DOB=DateTime.Now,CourseId=1 },
      new Student { OrgId = 1, StudentId=10,  FirstName = "Himanish", LastName = "B", FamilyId = 8, Gender="M",DOB=DateTime.Now,CourseId=1 }
        };

        }

        public IEnumerable<Student> GetAll()
        {
            return students;    
        }

        public Student Get(int id)
        {
           return students.Where(s => s.StudentId == id).FirstOrDefault();
        }

        public Student Add(Student item)
        {

            students.Add(item);
            return item;
        }

        public void Remove(int id)
        {
            var student= students.Where(s => s.StudentId == id).FirstOrDefault();
            students.Remove(student);
        }

        public bool Update(Student item)
        {
            //Student student = students.Where(s => s.StudentId == item.StudentId).FirstOrDefault();

            foreach (var std in students)
            {
                if(std.StudentId == item.StudentId)
                {
                    std.FirstName = item.FirstName;
                    std.LastName = item.LastName;
                    std.CourseId = item.CourseId;
                    std.FamilyId = item.FamilyId;
                    std.Gender = item.Gender;
                    std.OrgId = item.OrgId;
                    std.DOB = item.DOB;
                    return true;
                }
            }

            return false;

        }
    }
}
