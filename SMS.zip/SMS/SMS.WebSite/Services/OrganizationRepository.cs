﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{   

    public class AddressRepository  : IAddressRepository
    {
        public AddressRepository()
        {

        }

        public IEnumerable<Address> GetAll()
        {
           // return db.Books;
            return null;
        }

        public Address Get(int id)
        {
           // return db.Books.Find(id);
            return null;
        }

        public Address Add(Address item)
        {
            //db.Books.Add(item);
            //db.SaveChanges();
            //return item;

            return null;
        }

        public void Remove(int id)
        {
            //Student book = db.Books.Find(id);
            //db.Books.Remove(book);
            //db.SaveChanges();           
        }

        public bool Update(Address item)
        {
            //db.Entry(item).State = EntityState.Modified;
            //db.SaveChanges();
            return true;

        }
    }
}
