﻿using System.Collections.Generic;

namespace SMS
{
    public interface IStudentRepository
    {
        IEnumerable<Student> GetAll();
        Student Get(int id);
        Student Add(Student item);
        void Remove(int id);
        bool Update(Student item);
    }
}
