﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{   

    public class LookupRepository : ILookupRepository
    {
        public LookupRepository()
        {

        }

        public IEnumerable<Lookup> GetAll()
        {
           // return db.Books;
            return null;
        }

        public Lookup Get(int id)
        {
           // return db.Books.Find(id);
            return null;
        }

        public Lookup Add(Lookup item)
        {
            //db.Books.Add(item);
            //db.SaveChanges();
            //return item;

            return null;
        }

        public void Remove(int id)
        {
            //Student book = db.Books.Find(id);
            //db.Books.Remove(book);
            //db.SaveChanges();           
        }

        public bool Update(Lookup item)
        {
            //db.Entry(item).State = EntityState.Modified;
            //db.SaveChanges();
            return true;

        }
    }
}
