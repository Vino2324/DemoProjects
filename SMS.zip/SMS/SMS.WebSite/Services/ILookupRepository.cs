﻿using System.Collections.Generic;

namespace SMS
{
    public interface ILookupRepository
    {
        IEnumerable<Lookup> GetAll();
        Lookup Get(int id);
        Lookup Add(Lookup item);
        void Remove(int id);
        bool Update(Lookup item);
    }
}
