﻿using System.Collections.Generic;

namespace SMS
{
    public interface ITeacherRepository
    {
        IEnumerable<Teacher> GetAll();
        Teacher Get(int id);
        Teacher Add(Teacher item);
        void Remove(int id);
        bool Update(Teacher item);
    }
}
