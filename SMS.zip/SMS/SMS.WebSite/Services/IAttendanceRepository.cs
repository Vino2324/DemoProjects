﻿using System.Collections.Generic;

namespace SMS
{
    public interface IAttendanceRepository
    {
        IEnumerable<Attendance> GetAll();
        Attendance Get(int id);
        Attendance Add(Attendance item);
        void Remove(int id);
        bool Update(Attendance item);
    }
}
