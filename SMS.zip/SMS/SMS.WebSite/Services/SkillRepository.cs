﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS;

namespace SMS
{   

    public class SkillRepository : ISkillRepository
    {
        public SkillRepository()
        {

        }

        public IEnumerable<Skill> GetAll()
        {
           // return db.Books;
            return null;
        }

        public Skill Get(int id)
        {
           // return db.Books.Find(id);
            return null;
        }

        public Skill Add(Skill item)
        {
            //db.Books.Add(item);
            //db.SaveChanges();
            //return item;

            return null;
        }

        public void Remove(int id)
        {
            //Student book = db.Books.Find(id);
            //db.Books.Remove(book);
            //db.SaveChanges();           
        }

        public bool Update(Skill item)
        {
            //db.Entry(item).State = EntityState.Modified;
            //db.SaveChanges();
            return true;

        }
    }
}
