﻿using System.Collections.Generic;

namespace SMS
{
    public interface IAddressRepository
    {
        IEnumerable<Address> GetAll();
        Address Get(int id);
        Address Add(Address item);
        void Remove(int id);
        bool Update(Address item);
    }
}
