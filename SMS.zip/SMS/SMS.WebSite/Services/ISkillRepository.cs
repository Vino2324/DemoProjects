﻿using System.Collections.Generic;

namespace SMS
{
    public interface ISkillRepository
    {
        IEnumerable<Skill> GetAll();
        Skill Get(int id);
        Skill Add(Skill item);
        void Remove(int id);
        bool Update(Skill item);
    }
}
