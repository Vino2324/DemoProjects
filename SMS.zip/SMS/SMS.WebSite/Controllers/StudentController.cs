﻿#region Namespace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
#endregion
namespace SMS.WebSite.Controllers
{
    public class StudentController : ApiController
    {
        public static StudentRepository stdRepository = null;

        public StudentController()
        {
            stdRepository = new StudentRepository();
        }
    
       public HttpResponseMessage GetStudent(int id)
        {
            var student = stdRepository.Get(id);

           if(student==null)
           {
               return Request.CreateErrorResponse(HttpStatusCode.NotFound,"Not found");
           }

           return Request.CreateResponse<Student>(HttpStatusCode.OK, student);
        }
    }
}
