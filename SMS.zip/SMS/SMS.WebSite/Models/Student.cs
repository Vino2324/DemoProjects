﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS
{
    public class Student
    {
        public int OrgId { get; set; }
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int FamilyId { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public int CourseId { get; set; }
    }   
}