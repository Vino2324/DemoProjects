﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS
{
    public class Teacher
    {
        public int TeacherId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public int PrimaryContactNumber { get; set; }
        public int? SecondaryContactNumber { get; set; }
        public Address AddessInfo { get; set; }
        public List<Skill> Skill { get; set; }
    }
}