﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS
{
    public class Address
    {
        public int AddressId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public int PinCode { get; set; }
    }
}