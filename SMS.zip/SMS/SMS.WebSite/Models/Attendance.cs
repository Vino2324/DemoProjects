﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS
{
    public class Attendance
    {
        public int AttendanceId { get; set; }
        public string StudentId { get; set; }
        public int Date { get; set; }
        public byte Attended { get; set; }
        public string Reason { get; set; }
    }
}