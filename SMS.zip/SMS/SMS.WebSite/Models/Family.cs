﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS
{
    public class Family
    {
        public int FamilyId { get; set; }
        public int StudentId { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string FatherOccupation { get; set; }
        public string MotherOcuupation { get; set; }
        public string EmailAddress { get; set; }
        public int FatherContactNumber { get; set; }
        public int MotherContactNumber { get; set; }
        public Address AddessInfo { get; set; }
    }
}